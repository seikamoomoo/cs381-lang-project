# cs381-lang-project

Seika Mahmud - Mahmuds
Sriram Rakshith Kolar - Kolars
Swetha Jayapathy - Jayapaths


Introduction

Name of language: CAT 
Paradigm: Imperative
Something unique: Factorial implementation


Instructions to Run teh program:
	- Load the project.hs file in ghci and then it will successfully compile. 
	- To execute the functions: - euclid
								- fact
								- concatVar
								- concatInt
	The values are harcoded for now. A different Implementation of the porograms will be submitted during the final submission. 